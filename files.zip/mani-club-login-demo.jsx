import React, { useState } from "react";
import { Lock, Mail, ChevronDown, Shield, Clock, CreditCard, X } from "lucide-react";

const DEPARTMENTS = [
  { id: "super_admin", label: "Super Admin", note: "Pronari i platformës" },
  { id: "president", label: "Presidenti", note: "Qendra e Vendimeve" },
  { id: "head_coach", label: "Trajneri", note: "Drejtori Teknik & Sportiv" },
  { id: "staff", label: "Stafi Teknik", note: "Administrativ" },
  { id: "legal", label: "Juridik", note: "Kontrata & dokumente" },
  { id: "medical", label: "Mjekësor", note: "Sport Medicine" },
  { id: "analysis", label: "Analizë", note: "Të dhëna & video" },
  { id: "athletic", label: "Përgatitje Fizike", note: "GPS & teste" },
  { id: "first_team", label: "Ekipi i Parë", note: "Aksesi i lojtarit" },
  { id: "academy", label: "Akademia", note: "U7 – U19" },
];

function PitchMotif() {
  return (
    <svg
      viewBox="0 0 400 600"
      className="absolute inset-0 w-full h-full opacity-[0.07]"
      preserveAspectRatio="xMidYMid slice"
    >
      <line x1="0" y1="300" x2="400" y2="300" stroke="#fff" strokeWidth="1.5" />
      <circle cx="200" cy="300" r="70" fill="none" stroke="#fff" strokeWidth="1.5" />
      <circle cx="200" cy="300" r="2.5" fill="#fff" />
      <rect x="60" y="0" width="280" height="90" fill="none" stroke="#fff" strokeWidth="1.5" />
      <rect x="140" y="0" width="120" height="35" fill="none" stroke="#fff" strokeWidth="1.5" />
      <rect x="60" y="510" width="280" height="90" fill="none" stroke="#fff" strokeWidth="1.5" />
      <rect x="140" y="565" width="120" height="35" fill="none" stroke="#fff" strokeWidth="1.5" />
    </svg>
  );
}

function LicenseBanner({ client, onClose }) {
  const daysLeft = Math.max(
    0,
    Math.ceil((new Date(client.subscription_expires_at) - new Date()) / 86400000)
  );
  const isLow = daysLeft <= 7;

  return (
    <div
      className="sticky top-0 z-40 w-full text-white"
      style={{ background: isLow ? "#7c2d12" : "#0f172a" }}
    >
      <div className="max-w-6xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3 min-w-0">
          <span
            className="w-2 h-2 rounded-full shrink-0"
            style={{ background: client.status === "active" ? "#10b981" : "#ef4444" }}
          />
          <span className="font-semibold tracking-tight truncate">{client.name}</span>
          <span className="text-white/40 hidden sm:inline">·</span>
          <span
            className="hidden sm:inline text-sm px-2 py-0.5 rounded"
            style={{
              background: client.status === "active" ? "#10b98122" : "#ef444422",
              color: client.status === "active" ? "#34d399" : "#f87171",
            }}
          >
            {client.status === "active" ? "Aktiv" : "I skaduar"}
          </span>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <span
            className="flex items-center gap-1.5 text-sm font-mono"
            style={{ color: isLow ? "#fdba74" : "#94a3b8" }}
          >
            <Clock size={14} />
            {daysLeft} ditë të mbetura
          </span>
          <button
            className="flex items-center gap-1.5 text-sm font-semibold px-3 py-1.5 rounded-md transition"
            style={{ background: "#3b82f6" }}
          >
            <CreditCard size={14} />
            Menaxho Planin
          </button>
          {onClose && (
            <button onClick={onClose} className="text-white/40 hover:text-white/80 transition">
              <X size={16} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default function ManiClubLogin() {
  const [step, setStep] = useState("login"); // login | app
  const [deptOpen, setDeptOpen] = useState(false);
  const [dept, setDept] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const mockClient = {
    name: "FC Shiroka",
    status: "active",
    subscription_expires_at: "2026-08-21",
  };

  if (step === "app") {
    return (
      <div className="min-h-screen" style={{ background: "#f8fafc" }}>
        <LicenseBanner client={mockClient} onClose={() => setStep("login")} />
        <div className="max-w-6xl mx-auto px-4 py-12">
          <p
            className="text-xs font-mono tracking-widest uppercase mb-2"
            style={{ color: "#64748b" }}
          >
            E kyçur si
          </p>
          <h1
            className="text-3xl font-bold tracking-tight"
            style={{ color: "#0f172a", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            {DEPARTMENTS.find((d) => d.id === dept)?.label || "Përdorues"}
          </h1>
          <p className="mt-2" style={{ color: "#475569" }}>
            Kjo është pamja e panelit pas hyrjes — banner-i i licencës qëndron fiksuar lart
            gjithmonë, pavarësisht se cilën faqe të departamentit shikon.
          </p>
          <button
            onClick={() => setStep("login")}
            className="mt-6 text-sm font-semibold px-4 py-2 rounded-md text-white"
            style={{ background: "#1e3a8a" }}
          >
            ← Kthehu te hyrja
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Paneli i majtë — identiteti */}
      <div
        className="hidden md:flex md:w-[42%] relative flex-col justify-between p-10 overflow-hidden"
        style={{ background: "#0f172a" }}
      >
        <PitchMotif />
        <div className="relative z-10">
          <div className="flex items-center gap-2.5">
            <div
              className="w-9 h-9 rounded-md flex items-center justify-center font-bold text-white"
              style={{ background: "#3b82f6", fontFamily: "'Barlow Condensed', sans-serif" }}
            >
              MC
            </div>
            <span
              className="text-white font-bold tracking-tight text-lg"
              style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
            >
              MANI CLUB
            </span>
          </div>
        </div>

        <div className="relative z-10">
          <h1
            className="text-white text-5xl font-bold leading-[0.95] tracking-tight"
            style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            NJË PLATFORMË.
            <br />
            ÇDO DEPARTAMENT.
            <br />
            <span style={{ color: "#3b82f6" }}>ÇDO KLUB.</span>
          </h1>
          <p className="text-white/50 mt-5 max-w-sm text-sm leading-relaxed">
            Nga banka teknike te dhoma mjekësore, nga akademia U7 te zyra e presidentit —
            e gjithë klubi, në një sistem të vetëm.
          </p>
        </div>

        <p className="relative z-10 text-white/30 text-xs font-mono">
          v2026 · SaaS Multi-Klub
        </p>
      </div>

      {/* Paneli i djathtë — forma */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-10" style={{ background: "#f8fafc" }}>
        <div className="w-full max-w-sm">
          <div className="md:hidden flex items-center gap-2.5 mb-8">
            <div
              className="w-8 h-8 rounded-md flex items-center justify-center font-bold text-white text-sm"
              style={{ background: "#1e3a8a" }}
            >
              MC
            </div>
            <span className="font-bold tracking-tight" style={{ color: "#0f172a" }}>
              MANI CLUB
            </span>
          </div>

          <h2 className="text-xl font-bold" style={{ color: "#0f172a" }}>
            Hyrje në sistem
          </h2>
          <p className="text-sm mt-1 mb-6" style={{ color: "#64748b" }}>
            Zgjidh departamentin dhe vendos kredencialet.
          </p>

          {/* Zgjedhja e departamentit */}
          <div className="relative mb-4">
            <button
              onClick={() => setDeptOpen(!deptOpen)}
              className="w-full flex items-center justify-between gap-2 px-3.5 py-3 rounded-lg border text-sm text-left transition"
              style={{
                borderColor: dept ? "#3b82f6" : "#e2e8f0",
                background: "#fff",
              }}
            >
              <span className="flex items-center gap-2 min-w-0">
                <Shield size={16} style={{ color: "#3b82f6" }} className="shrink-0" />
                {dept ? (
                  <span className="min-w-0">
                    <span className="font-semibold" style={{ color: "#0f172a" }}>
                      {DEPARTMENTS.find((d) => d.id === dept)?.label}
                    </span>
                    <span className="ml-1.5" style={{ color: "#94a3b8" }}>
                      {DEPARTMENTS.find((d) => d.id === dept)?.note}
                    </span>
                  </span>
                ) : (
                  <span style={{ color: "#94a3b8" }}>Zgjidh departamentin</span>
                )}
              </span>
              <ChevronDown
                size={16}
                style={{ color: "#94a3b8", transform: deptOpen ? "rotate(180deg)" : "none" }}
                className="transition-transform shrink-0"
              />
            </button>

            {deptOpen && (
              <div
                className="absolute z-20 mt-1.5 w-full rounded-lg border bg-white shadow-lg overflow-hidden max-h-64 overflow-y-auto"
                style={{ borderColor: "#e2e8f0" }}
              >
                {DEPARTMENTS.map((d) => (
                  <button
                    key={d.id}
                    onClick={() => {
                      setDept(d.id);
                      setDeptOpen(false);
                    }}
                    className="w-full text-left px-3.5 py-2.5 text-sm hover:bg-slate-50 transition flex items-center justify-between"
                  >
                    <span style={{ color: "#0f172a" }} className="font-medium">
                      {d.label}
                    </span>
                    <span className="text-xs" style={{ color: "#94a3b8" }}>
                      {d.note}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Email */}
          <div className="mb-4">
            <label className="text-xs font-semibold uppercase tracking-wide" style={{ color: "#64748b" }}>
              Email
            </label>
            <div className="relative mt-1.5">
              <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: "#94a3b8" }} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="emri@klubi.al"
                className="w-full pl-10 pr-3.5 py-3 rounded-lg border text-sm outline-none transition"
                style={{ borderColor: "#e2e8f0" }}
                onFocus={(e) => (e.target.style.borderColor = "#3b82f6")}
                onBlur={(e) => (e.target.style.borderColor = "#e2e8f0")}
              />
            </div>
          </div>

          {/* Password */}
          <div className="mb-6">
            <label className="text-xs font-semibold uppercase tracking-wide" style={{ color: "#64748b" }}>
              Fjalëkalimi
            </label>
            <div className="relative mt-1.5">
              <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: "#94a3b8" }} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-3.5 py-3 rounded-lg border text-sm outline-none transition"
                style={{ borderColor: "#e2e8f0" }}
                onFocus={(e) => (e.target.style.borderColor = "#3b82f6")}
                onBlur={(e) => (e.target.style.borderColor = "#e2e8f0")}
              />
            </div>
          </div>

          <button
            disabled={!dept || !email || !password}
            onClick={() => setStep("app")}
            className="w-full py-3 rounded-lg font-semibold text-white text-sm transition disabled:opacity-40 disabled:cursor-not-allowed"
            style={{ background: "#1e3a8a" }}
          >
            Hyr në Platformë
          </button>

          <p className="text-xs text-center mt-6" style={{ color: "#cbd5e1" }}>
            client_id-ja e sesionit përcaktohet automatikisht pas hyrjes
          </p>
        </div>
      </div>
    </div>
  );
}
